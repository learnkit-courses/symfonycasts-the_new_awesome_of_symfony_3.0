
## New Directory structure

- app/cache -> var/cache
- update phpstorm configuration
- sessions are out of the cache
- bin/console
- app is really just configuration

## Guard Authentication
- look at the steps!


- autowiring
- assetic
- new form type stuff
- property info component
- new profiler
- new, simpler dir structure
- UserLoaderInterface for Doctrine
- AbstractVoter
- new SymfonyStyle type of stuff
- Ldap

+ directory structure
+ guard
+ easier custom auth errors

- 700 commits